require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const Project = require('./models/Project');

const projects = [
  {
    title: 'E-Commerce Platform',
    description:
      'Full-featured e-commerce web app with cart, payment integration via Stripe, and admin dashboard. Handles real-time inventory updates and order tracking.',
    techStack: ['React', 'Node.js', 'Express', 'MongoDB', 'Stripe', 'Redis'],
    link: 'https://demo.example.com/ecommerce',
    repoLink: 'https://github.com/yourusername/ecommerce',
    featured: true,
    order: 1,
  },
  {
    title: 'Real-Time Chat App',
    description:
      'WebSocket-based chat application supporting multiple rooms, private messaging, and file sharing. Built with Socket.IO and React.',
    techStack: ['React', 'Socket.IO', 'Node.js', 'MongoDB', 'JWT'],
    link: 'https://demo.example.com/chat',
    repoLink: 'https://github.com/yourusername/chat-app',
    featured: true,
    order: 2,
  },
  {
    title: 'DevOps Dashboard',
    description:
      'Monitoring dashboard for Docker containers and CI/CD pipelines. Visualizes metrics with Chart.js and supports webhook integrations.',
    techStack: ['Vue.js', 'Docker', 'Node.js', 'PostgreSQL', 'Chart.js'],
    link: '',
    repoLink: 'https://github.com/yourusername/devops-dashboard',
    featured: false,
    order: 3,
  },
  {
    title: 'AI Content Generator',
    description:
      'Content generation tool powered by OpenAI API. Features prompt templates, history management, and export to multiple formats.',
    techStack: ['Next.js', 'OpenAI API', 'TypeScript', 'Prisma', 'PostgreSQL'],
    link: 'https://demo.example.com/ai-gen',
    repoLink: 'https://github.com/yourusername/ai-content',
    featured: true,
    order: 4,
  },
  {
    title: 'Task Management API',
    description:
      'RESTful API for project and task management with role-based access control, team collaboration features, and email notifications.',
    techStack: ['Node.js', 'Express', 'MongoDB', 'JWT', 'Nodemailer'],
    link: '',
    repoLink: 'https://github.com/yourusername/task-api',
    featured: false,
    order: 5,
  },
  {
    title: 'Portfolio CMS',
    description:
      'Headless CMS built for developer portfolios. Supports Markdown content, image optimization, and deployment via GitHub Actions.',
    techStack: ['Next.js', 'TypeScript', 'Contentful', 'Tailwind CSS'],
    link: 'https://demo.example.com/cms',
    repoLink: 'https://github.com/yourusername/portfolio-cms',
    featured: false,
    order: 6,
  },
];

const seedDB = async () => {
  await connectDB();
  try {
    await Project.deleteMany({});
    const created = await Project.insertMany(projects);
    console.log(`✅ Seeded ${created.length} projects`);
  } catch (err) {
    console.error('❌ Seed error:', err);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected');
  }
};

seedDB();
