const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { createContact, getContacts } = require('../controllers/contactController');

const contactValidation = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
  body('email').trim().isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('message').trim().notEmpty().withMessage('Message is required').isLength({ max: 2000 }),
];

router.post('/', contactValidation, createContact);
router.get('/', getContacts);

module.exports = router;
