# 🚀 Portfolio Fullstack — React + Node.js + MongoDB

Portfolio developer profesional dengan React (frontend) dan Express + MongoDB (backend).

---

## 📁 Struktur Folder

```
portfolio/
├── frontend/               # React + Vite + Tailwind
│   └── src/
│       ├── components/     # Navbar, Footer, ProjectCard
│       ├── pages/          # Home, Projects, Contact
│       ├── hooks/          # useProjects
│       └── utils/          # api.js
│
└── backend/                # Node.js + Express + MongoDB
    ├── config/             # db.js
    ├── controllers/        # projectController, contactController
    ├── middleware/         # errorHandler
    ├── models/             # Project, Contact (Mongoose)
    ├── routes/             # projectRoutes, contactRoutes
    ├── server.js
    └── seed.js
```

---

## ⚙️ Setup & Menjalankan

### 1. Prerequisites
- Node.js v18+
- MongoDB (local atau [MongoDB Atlas](https://cloud.mongodb.com))

---

### 2. Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env — isi MONGODB_URI kamu
npm run dev
```

**Seed data project:**
```bash
npm run seed
```

Backend berjalan di: `http://localhost:5000`

---

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend berjalan di: `http://localhost:5173`

> Vite sudah dikonfigurasi proxy ke backend — tidak perlu setting CORS manual saat development.

---

## 🔌 API Endpoints

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/api/projects` | Ambil semua project |
| GET | `/api/projects/:id` | Ambil project by ID |
| POST | `/api/contact` | Kirim pesan kontak |
| GET | `/api/contact` | Lihat semua pesan (admin) |
| GET | `/api/health` | Health check server |

**POST /api/contact — Body:**
```json
{
  "name": "Budi Santoso",
  "email": "budi@example.com",
  "message": "Halo, saya tertarik dengan jasa Anda."
}
```

---

## 🌍 Production Deployment

### Backend (Railway / Render / VPS)
1. Set env vars: `MONGODB_URI`, `PORT`, `NODE_ENV=production`, `CLIENT_URL`
2. `npm start`

### Frontend (Vercel / Netlify)
1. Set env var: `VITE_API_URL=https://your-api.com/api`
2. Build: `npm run build`
3. Deploy folder `dist/`

---

## 🎨 Kustomisasi

- **Nama & info**: Edit `src/pages/Home.jsx` (stats, bio, skills)
- **Kontak info**: Edit `src/pages/Contact.jsx`
- **Warna accent**: Edit `tailwind.config.js` → `colors.acid`
- **Font**: Edit `index.html` Google Fonts link + `tailwind.config.js`
- **Tambah project**: Gunakan `seed.js` atau langsung POST ke MongoDB

---

## 🛠 Tech Stack

| Layer | Teknologi |
|-------|-----------|
| Frontend | React 18, React Router v6, Tailwind CSS v3 |
| Build | Vite 5 |
| Backend | Node.js, Express 4 |
| Database | MongoDB + Mongoose |
| Validation | express-validator |
| Fonts | Syne, DM Sans, JetBrains Mono |
