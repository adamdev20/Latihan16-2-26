const BASE_URL = import.meta.env.VITE_API_URL || '/api'

export async function fetchProjects() {
  const res = await fetch(`${BASE_URL}/projects`)
  if (!res.ok) throw new Error('Failed to fetch projects')
  const json = await res.json()
  return json.data
}

export async function sendContact(payload) {
  const res = await fetch(`${BASE_URL}/contact`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  const json = await res.json()
  if (!res.ok) throw new Error(json.message || 'Failed to send message')
  return json
}
