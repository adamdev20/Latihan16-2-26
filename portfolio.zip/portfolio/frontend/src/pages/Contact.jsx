import { useState } from 'react'
import { sendContact } from '../utils/api'

const contactInfo = [
  { label: 'Email', value: 'alex@example.com', href: 'mailto:alex@example.com' },
  { label: 'LinkedIn', value: '/in/alexdev', href: 'https://linkedin.com' },
  { label: 'GitHub', value: '@alexdev', href: 'https://github.com' },
  { label: 'Location', value: 'Jakarta, Indonesia', href: null },
]

const STATUS = { IDLE: 'idle', LOADING: 'loading', SUCCESS: 'success', ERROR: 'error' }

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [status, setStatus] = useState(STATUS.IDLE)
  const [errorMsg, setErrorMsg] = useState('')

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus(STATUS.LOADING)
    setErrorMsg('')
    try {
      await sendContact(form)
      setStatus(STATUS.SUCCESS)
      setForm({ name: '', email: '', message: '' })
    } catch (err) {
      setStatus(STATUS.ERROR)
      setErrorMsg(err.message)
    }
  }

  return (
    <div className="pt-28 pb-24 min-h-screen">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="mb-16">
          <span className="section-label">Contact</span>
          <h1 className="mt-4 font-display font-800 text-5xl lg:text-6xl text-ash-100 leading-tight">
            Let's build something<br />
            <span className="text-acid-500">together</span>
          </h1>
          <p className="mt-4 font-body text-ash-400 max-w-lg leading-relaxed">
            Have a project in mind? Looking for a developer to join your team?
            I'd love to hear from you.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="space-y-4">
              {contactInfo.map(({ label, value, href }) => (
                <div key={label} className="glass rounded-xl p-5 group">
                  <p className="font-mono text-[10px] tracking-widest text-acid-500 mb-1">{label.toUpperCase()}</p>
                  {href ? (
                    <a
                      href={href}
                      target={href.startsWith('http') ? '_blank' : undefined}
                      rel="noreferrer"
                      className="font-body text-ash-200 hover:text-acid-400 transition-colors text-sm"
                    >
                      {value}
                    </a>
                  ) : (
                    <p className="font-body text-ash-200 text-sm">{value}</p>
                  )}
                </div>
              ))}
            </div>

            {/* Availability badge */}
            <div className="glass rounded-xl p-5 border-l-2 border-acid-500">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2 h-2 rounded-full bg-acid-500 animate-pulse" />
                <p className="font-mono text-xs text-acid-500">AVAILABLE FOR WORK</p>
              </div>
              <p className="font-body text-sm text-ash-400">
                Currently open to freelance projects and full-time opportunities.
              </p>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="glass rounded-2xl p-8">
              {status === STATUS.SUCCESS ? (
                <div className="py-12 text-center space-y-4 animate-fade-in">
                  <div className="text-5xl">✅</div>
                  <h3 className="font-display font-700 text-2xl text-ash-100">Message sent!</h3>
                  <p className="font-body text-ash-400">
                    Thanks for reaching out. I'll get back to you within 24 hours.
                  </p>
                  <button
                    onClick={() => setStatus(STATUS.IDLE)}
                    className="btn-ghost mt-4"
                  >
                    Send another
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Name */}
                  <div className="space-y-2">
                    <label className="font-mono text-xs text-ash-400 tracking-widest" htmlFor="name">
                      NAME <span className="text-ember-500">*</span>
                    </label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Your name"
                      className="w-full bg-ink-900/60 border border-ink-600 rounded-xl px-4 py-3 text-ash-200 placeholder-ink-600 font-body text-sm outline-none focus:border-acid-500/60 focus:ring-1 focus:ring-acid-500/20 transition-all"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-2">
                    <label className="font-mono text-xs text-ash-400 tracking-widest" htmlFor="email">
                      EMAIL <span className="text-ember-500">*</span>
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={form.email}
                      onChange={handleChange}
                      placeholder="you@example.com"
                      className="w-full bg-ink-900/60 border border-ink-600 rounded-xl px-4 py-3 text-ash-200 placeholder-ink-600 font-body text-sm outline-none focus:border-acid-500/60 focus:ring-1 focus:ring-acid-500/20 transition-all"
                    />
                  </div>

                  {/* Message */}
                  <div className="space-y-2">
                    <label className="font-mono text-xs text-ash-400 tracking-widest" htmlFor="message">
                      MESSAGE <span className="text-ember-500">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={6}
                      value={form.message}
                      onChange={handleChange}
                      placeholder="Tell me about your project..."
                      className="w-full bg-ink-900/60 border border-ink-600 rounded-xl px-4 py-3 text-ash-200 placeholder-ink-600 font-body text-sm outline-none focus:border-acid-500/60 focus:ring-1 focus:ring-acid-500/20 transition-all resize-none"
                    />
                  </div>

                  {/* Error */}
                  {status === STATUS.ERROR && (
                    <div className="p-4 rounded-xl bg-ember-500/10 border border-ember-500/30">
                      <p className="font-mono text-xs text-ember-400">
                        ⚠ {errorMsg || 'Something went wrong. Please try again.'}
                      </p>
                    </div>
                  )}

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={status === STATUS.LOADING}
                    className="w-full btn-primary justify-center py-4 rounded-xl disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {status === STATUS.LOADING ? (
                      <>
                        <span className="w-4 h-4 border-2 border-ink-950/30 border-t-ink-950 rounded-full animate-spin" />
                        Sending...
                      </>
                    ) : (
                      'Send Message →'
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
