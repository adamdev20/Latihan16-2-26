import { Link } from 'react-router-dom'
import { useProjects } from '../hooks/useProjects'
import ProjectCard from '../components/ProjectCard'

const skills = [
  { category: 'Frontend', items: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Vue.js'] },
  { category: 'Backend', items: ['Node.js', 'Express', 'Python', 'REST API', 'GraphQL'] },
  { category: 'Database', items: ['MongoDB', 'PostgreSQL', 'Redis', 'Prisma', 'Mongoose'] },
  { category: 'DevOps', items: ['Docker', 'GitHub Actions', 'AWS', 'Vercel', 'Nginx'] },
]

function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden noise-bg pt-16">
      {/* Background grid */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(#c8f000 1px, transparent 1px), linear-gradient(90deg, #c8f000 1px, transparent 1px)`,
          backgroundSize: '64px 64px',
        }}
      />

      {/* Glows */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-acid-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-80 h-80 bg-ember-500/8 rounded-full blur-3xl" />

      <div className="relative max-w-6xl mx-auto px-6 w-full">
        <div className="max-w-3xl">
          {/* Label */}
          <div className="opacity-0 animate-fade-up animation-delay-100" style={{ animationFillMode: 'forwards' }}>
            <span className="section-label">Full Stack Developer</span>
          </div>

          {/* Headline */}
          <h1
            className="mt-6 font-display font-800 text-5xl sm:text-7xl lg:text-8xl text-ash-100 leading-[0.95] tracking-tight opacity-0 animate-fade-up animation-delay-200"
            style={{ animationFillMode: 'forwards' }}
          >
            Building{' '}
            <span className="text-acid-500">digital</span>
            <br />
            products that{' '}
            <span className="relative">
              matter
              <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 200 8" fill="none">
                <path d="M0 6 Q100 0 200 6" stroke="#c8f000" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
              </svg>
            </span>
            <span className="text-acid-500 animate-blink">_</span>
          </h1>

          {/* Subtext */}
          <p
            className="mt-8 font-body text-lg text-ash-400 max-w-lg leading-relaxed opacity-0 animate-fade-up animation-delay-300"
            style={{ animationFillMode: 'forwards' }}
          >
            I'm Alex — a full stack developer specializing in React, Node.js, and
            scalable architecture. I turn complex problems into clean, performant solutions.
          </p>

          {/* CTAs */}
          <div
            className="mt-10 flex flex-wrap gap-4 opacity-0 animate-fade-up animation-delay-400"
            style={{ animationFillMode: 'forwards' }}
          >
            <Link to="/projects" className="btn-primary">
              View Projects →
            </Link>
            <Link to="/contact" className="btn-ghost">
              Get in Touch
            </Link>
          </div>

          {/* Stats */}
          <div
            className="mt-16 flex flex-wrap gap-10 opacity-0 animate-fade-up animation-delay-500"
            style={{ animationFillMode: 'forwards' }}
          >
            {[
              { num: '3+', label: 'Years Experience' },
              { num: '20+', label: 'Projects Shipped' },
              { num: '10+', label: 'Happy Clients' },
            ].map(({ num, label }) => (
              <div key={label}>
                <p className="font-display font-800 text-3xl text-acid-500">{num}</p>
                <p className="font-mono text-xs text-ash-400 mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Floating badge */}
        <div className="hidden lg:flex absolute right-6 top-1/2 -translate-y-1/2 w-48 h-48 items-center justify-center animate-float">
          <div className="relative w-full h-full">
            <svg className="w-full h-full animate-spin-slow" viewBox="0 0 200 200">
              <path
                id="circle"
                d="M 100,100 m -75,0 a 75,75 0 1,1 150,0 a 75,75 0 1,1 -150,0"
                fill="none"
              />
              <text className="text-[13px]" fill="#9ba3b8">
                <textPath href="#circle" startOffset="0%">
                  OPEN TO WORK • FULL STACK DEV • NODE.JS • REACT •{' '}
                </textPath>
              </text>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-3xl">⚡</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40">
        <span className="font-mono text-[10px] tracking-widest text-ash-400">SCROLL</span>
        <div className="w-px h-10 bg-gradient-to-b from-ash-400 to-transparent" />
      </div>
    </section>
  )
}

function AboutSection() {
  return (
    <section id="about" className="py-28 bg-ink-900/40">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left */}
          <div>
            <span className="section-label">About Me</span>
            <h2 className="mt-4 font-display font-800 text-4xl lg:text-5xl text-ash-100 leading-tight">
              Code is craft,<br />
              <span className="text-acid-500">not just syntax</span>
            </h2>
            <div className="mt-6 space-y-4 text-ash-400 leading-relaxed">
              <p>
                I'm a full stack developer based in Jakarta with a passion for building products
                that are both technically sound and delightful to use. My stack centers around
                the JavaScript ecosystem — React on the front, Node.js on the back.
              </p>
              <p>
                I care deeply about clean architecture, developer experience, and shipping
                products that scale. Whether it's a pixel-perfect UI or a high-throughput API,
                I bring the same attention to detail to every layer.
              </p>
              <p>
                When I'm not coding, you'll find me contributing to open source, writing
                technical articles, or tinkering with side projects.
              </p>
            </div>
            <div className="mt-8 flex gap-4">
              <Link to="/contact" className="btn-primary">
                Hire Me
              </Link>
              <a href="https://github.com" target="_blank" rel="noreferrer" className="btn-ghost">
                GitHub ↗
              </a>
            </div>
          </div>

          {/* Right — skills */}
          <div className="space-y-6">
            {skills.map(({ category, items }) => (
              <div key={category} className="glass rounded-xl p-5">
                <p className="font-mono text-xs text-acid-500 tracking-widest mb-3">{category.toUpperCase()}</p>
                <div className="flex flex-wrap gap-2">
                  {items.map((item) => (
                    <span
                      key={item}
                      className="font-mono text-xs px-3 py-1.5 rounded-lg bg-ink-900/60 text-ash-300 border border-ink-600/30 hover:border-acid-500/40 hover:text-acid-400 transition-colors"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function FeaturedProjects() {
  const { projects, loading, error } = useProjects()
  const featured = projects.filter((p) => p.featured).slice(0, 3)

  return (
    <section className="py-28">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-end justify-between mb-12">
          <div>
            <span className="section-label">Projects</span>
            <h2 className="mt-4 font-display font-800 text-4xl lg:text-5xl text-ash-100 leading-tight">
              Selected work
            </h2>
          </div>
          <Link
            to="/projects"
            className="hidden md:inline-flex items-center gap-2 font-mono text-sm text-ash-400 hover:text-acid-500 transition-colors"
          >
            All projects →
          </Link>
        </div>

        {loading && (
          <div className="grid md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="glass rounded-2xl h-64 animate-pulse" />
            ))}
          </div>
        )}

        {error && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="font-mono text-sm text-ember-400">Backend not connected — showing placeholder</p>
            <p className="font-mono text-xs text-ash-400 mt-2">Start your server: cd backend && npm run dev</p>
          </div>
        )}

        {!loading && !error && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featured.map((project, i) => (
              <ProjectCard key={project._id} project={project} index={i} />
            ))}
          </div>
        )}

        <div className="mt-10 text-center md:hidden">
          <Link to="/projects" className="btn-ghost">
            View All Projects →
          </Link>
        </div>
      </div>
    </section>
  )
}

export default function Home() {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <FeaturedProjects />
    </>
  )
}
