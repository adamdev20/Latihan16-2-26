import { useState } from 'react'
import { useProjects } from '../hooks/useProjects'
import ProjectCard from '../components/ProjectCard'

const ALL = 'All'

export default function Projects() {
  const { projects, loading, error } = useProjects()
  const [filter, setFilter] = useState(ALL)

  // Collect all unique techs
  const allTechs = [ALL, ...new Set(projects.flatMap((p) => p.techStack))].slice(0, 10)

  const filtered =
    filter === ALL ? projects : projects.filter((p) => p.techStack.includes(filter))

  return (
    <div className="pt-28 pb-24 min-h-screen">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="mb-14">
          <span className="section-label">Portfolio</span>
          <h1 className="mt-4 font-display font-800 text-5xl lg:text-6xl text-ash-100 leading-tight">
            All Projects
          </h1>
          <p className="mt-4 font-body text-ash-400 max-w-lg leading-relaxed">
            A collection of things I've built — from side projects to production systems.
          </p>
        </div>

        {/* Filter chips */}
        {!loading && !error && (
          <div className="flex flex-wrap gap-2 mb-12">
            {allTechs.map((tech) => (
              <button
                key={tech}
                onClick={() => setFilter(tech)}
                className={`font-mono text-xs px-4 py-2 rounded-full border transition-all duration-200 ${
                  filter === tech
                    ? 'bg-acid-500 text-ink-950 border-acid-500'
                    : 'border-ink-600 text-ash-400 hover:border-ash-400 hover:text-ash-200'
                }`}
              >
                {tech}
              </button>
            ))}
          </div>
        )}

        {/* Loading skeletons */}
        {loading && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="glass rounded-2xl h-72 animate-pulse" />
            ))}
          </div>
        )}

        {/* Error state */}
        {error && (
          <div className="glass rounded-2xl p-12 text-center">
            <div className="text-4xl mb-4">🔌</div>
            <p className="font-display font-700 text-xl text-ash-100 mb-2">Backend not connected</p>
            <p className="font-mono text-sm text-ash-400">
              Run <code className="text-acid-500">cd backend && npm run dev</code> to start the API
            </p>
          </div>
        )}

        {/* Project grid */}
        {!loading && !error && (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((project, i) => (
                <ProjectCard key={project._id} project={project} index={i} />
              ))}
            </div>
            {filtered.length === 0 && (
              <p className="font-mono text-sm text-ash-400 text-center py-16">
                No projects match this filter.
              </p>
            )}
          </>
        )}
      </div>
    </div>
  )
}
