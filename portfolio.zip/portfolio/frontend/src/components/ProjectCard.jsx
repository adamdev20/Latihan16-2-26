export default function ProjectCard({ project, index }) {
  const { title, description, techStack, link, repoLink, featured } = project

  return (
    <article
      className="group relative glass rounded-2xl p-6 card-hover flex flex-col gap-4 opacity-0 animate-fade-up"
      style={{ animationDelay: `${index * 80}ms`, animationFillMode: 'forwards' }}
    >
      {/* Featured badge */}
      {featured && (
        <span className="absolute top-5 right-5 font-mono text-[10px] tracking-widest text-acid-500 border border-acid-500/40 rounded-full px-2.5 py-0.5 bg-acid-500/5">
          FEATURED
        </span>
      )}

      {/* Number */}
      <span className="font-mono text-xs text-ink-600 select-none">
        {String(index + 1).padStart(2, '0')}
      </span>

      {/* Title */}
      <h3 className="font-display font-700 text-xl text-ash-100 group-hover:text-acid-500 transition-colors leading-tight">
        {title}
      </h3>

      {/* Description */}
      <p className="font-body text-sm text-ash-400 leading-relaxed flex-1">
        {description}
      </p>

      {/* Tech stack */}
      <div className="flex flex-wrap gap-2">
        {techStack.map((tech) => (
          <span
            key={tech}
            className="font-mono text-[11px] px-2.5 py-1 rounded-md bg-ink-700/60 text-ash-400 border border-ink-600/40"
          >
            {tech}
          </span>
        ))}
      </div>

      {/* Links */}
      <div className="flex items-center gap-3 pt-1 border-t border-ink-700/40">
        {link && (
          <a
            href={link}
            target="_blank"
            rel="noreferrer"
            className="font-mono text-xs text-acid-500 hover:text-acid-400 transition-colors flex items-center gap-1"
          >
            Live Demo ↗
          </a>
        )}
        {repoLink && (
          <a
            href={repoLink}
            target="_blank"
            rel="noreferrer"
            className="font-mono text-xs text-ash-400 hover:text-ash-200 transition-colors flex items-center gap-1"
          >
            GitHub →
          </a>
        )}
        {!link && !repoLink && (
          <span className="font-mono text-xs text-ink-600">Private project</span>
        )}
      </div>
    </article>
  )
}
