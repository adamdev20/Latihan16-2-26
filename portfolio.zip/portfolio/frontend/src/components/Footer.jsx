import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="border-t border-ink-700/60 bg-ink-900/40">
      <div className="max-w-6xl mx-auto px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="font-mono text-xs text-ash-400">
          © {new Date().getFullYear()} alex.dev — Built with React + Node.js
        </p>
        <div className="flex items-center gap-6">
          {['GitHub', 'LinkedIn', 'Twitter'].map((s) => (
            <a
              key={s}
              href="#"
              className="font-mono text-xs text-ash-400 hover:text-acid-500 transition-colors"
            >
              {s}
            </a>
          ))}
        </div>
      </div>
    </footer>
  )
}
